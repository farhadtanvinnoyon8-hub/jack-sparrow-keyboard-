package com.jacksparrow.keyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.content.Context

class JackSparrowImeService : InputMethodService() {
    private var bangla = false
    private var emojiMode = false
    private var dark = true
    private val prefs by lazy { getSharedPreferences("keyboard_prefs", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        dark = prefs.getBoolean("dark_theme", true)
    }

    override fun onCreateInputView(): View {
        dark = prefs.getBoolean("dark_theme", true)
        return buildKeyboard()
    }

    private fun buildKeyboard(): View {
        val bg = if (dark) Color.rgb(10, 16, 32) else Color.rgb(232, 237, 246)
        val keyBg = if (dark) Color.rgb(28, 39, 62) else Color.WHITE
        val fg = if (dark) Color.WHITE else Color.rgb(20, 28, 45)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 6, 4, 6)
            setBackgroundColor(bg)
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        toolbar.addView(toolButton(if (bangla) "বাংলা" else "EN", keyBg, fg) {
            bangla = !bangla; emojiMode = false; setInputView(buildKeyboard())
        }, weighted())
        toolbar.addView(toolButton("☺ Emoji", keyBg, fg) {
            emojiMode = !emojiMode; setInputView(buildKeyboard())
        }, weighted())
        toolbar.addView(toolButton("⚙", keyBg, fg) {
            try { requestShowSelf(0) } catch (_: Exception) {}
        }, weighted())
        root.addView(toolbar)

        if (emojiMode) {
            addRow(root, listOf("😀","😂","🥹","😍","😘","🫦","😭","🔥","⚓","❤️"), keyBg, fg, 42)
            addRow(root, listOf("👍","🙏","💯","😎","🥰","🤔","🎉","✨","💀","😈"), keyBg, fg, 42)
            addRow(root, listOf("ABC","⌫","↵"), keyBg, fg, 42)
            return root
        }

        val rows = if (bangla) listOf(
            listOf("অ","আ","ই","ঈ","উ","ঊ","এ","ঐ","ও","ঔ"),
            listOf("ক","খ","গ","ঘ","চ","ছ","জ","ঝ","ট"),
            listOf("ঠ","ড","ঢ","ত","থ","দ","ধ","ন","প"),
            listOf("ফ","ব","ভ","ম","য","র","ল","স","হ"),
            listOf("?123","EN","☺","space","⌫","↵")
        ) else listOf(
            listOf("q","w","e","r","t","y","u","i","o","p"),
            listOf("a","s","d","f","g","h","j","k","l"),
            listOf("⇧","z","x","c","v","b","n","m","⌫"),
            listOf("?123",",","☺","space",".","↵")
        )
        rows.forEachIndexed { index, row ->
            addRow(root, row, keyBg, fg, if (index == rows.lastIndex) 46 else 44)
        }
        return root
    }

    private fun addRow(root: LinearLayout, labels: List<String>, keyBg: Int, fg: Int, height: Int) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        labels.forEach { label ->
            row.addView(keyButton(label, keyBg, fg), weighted(if (label in listOf("space", "↵", "⌫", "?123", "ABC", "EN")) 1.35f else 1f, height))
        }
        val lp = LinearLayout.LayoutParams(-1, height).apply { topMargin = 4 }
        root.addView(row, lp)
    }

    private fun keyButton(label: String, keyBg: Int, fg: Int) = Button(this).apply {
        text = if (label == "space") "English / বাংলা" else label
        textSize = if (label.length > 2) 12f else 18f
        setTextColor(fg)
        setBackgroundColor(keyBg)
        isAllCaps = false
        setPadding(0, 0, 0, 0)
        typeface = Typeface.DEFAULT
        setOnClickListener { handleKey(label) }
    }

    private fun toolButton(label: String, keyBg: Int, fg: Int, action: () -> Unit) =
        Button(this).apply {
            text = label
            textSize = 13f
            setTextColor(fg)
            setBackgroundColor(keyBg)
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "⌫" -> {
                val selected = ic.getSelectedText(0)
                if (selected != null && selected.isNotEmpty()) ic.commitText("", 1)
                else ic.deleteSurroundingText(1, 0)
            }
            "↵" -> ic.commitText("\n", 1)
            "space" -> ic.commitText(" ", 1)
            "☺" -> { emojiMode = true; setInputView(buildKeyboard()) }
            "EN" -> { bangla = false; emojiMode = false; setInputView(buildKeyboard()) }
            "ABC" -> { emojiMode = false; setInputView(buildKeyboard()) }
            "⇧" -> { /* Shift/capitalization can be enhanced in a later version. */ }
            "?123" -> { ic.commitText("", 1) }
            else -> ic.commitText(key, 1)
        }
    }

    private fun weighted(weight: Float = 1f, height: Int = 44) =
        LinearLayout.LayoutParams(0, height, weight).apply {
            setMargins(2, 1, 2, 1)
        }
}
