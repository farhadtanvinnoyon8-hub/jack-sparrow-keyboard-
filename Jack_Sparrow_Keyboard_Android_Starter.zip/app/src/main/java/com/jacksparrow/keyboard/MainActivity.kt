package com.jacksparrow.keyboard

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("keyboard_prefs", Context.MODE_PRIVATE) }
    private val channelUrl = "https://t.me/jacksparrow995"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val dark = prefs.getBoolean("dark_theme", true)
        val bg = if (dark) Color.rgb(8, 13, 28) else Color.rgb(245, 247, 252)
        val fg = if (dark) Color.WHITE else Color.rgb(20, 28, 45)
        val accent = Color.rgb(43, 125, 255)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 40, 28, 28)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "⚓ JACK SPARROW\nKEYBOARD"
            textSize = 28f
            setTextColor(fg)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "\nবাংলা + English • Emoji • Custom Themes"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(fg)
        }
        root.addView(subtitle, matchWrap())

        root.addView(makeButton("1. Enable Keyboard", accent) {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }, matchWrap(18))
        root.addView(makeButton("2. Choose Default Keyboard", accent) {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }, matchWrap(10))
        root.addView(makeButton(if (dark) "Theme: Dark (tap for Light)" else "Theme: Light (tap for Dark)", Color.rgb(105, 80, 210)) {
            prefs.edit().putBoolean("dark_theme", !dark).apply()
            render()
        }, matchWrap(10))
        root.addView(makeButton("Open Jack Sparrow Telegram Channel", Color.rgb(0, 136, 204)) {
            openUrl(channelUrl)
        }, matchWrap(10))
        root.addView(makeButton("Check for Updates", Color.rgb(20, 150, 100)) {
            Toast.makeText(this, "নতুন APK/Update-এর জন্য Telegram Channel দেখুন।", Toast.LENGTH_LONG).show()
            openUrl(channelUrl)
        }, matchWrap(10))

        val note = TextView(this).apply {
            text = "\nDeveloper: Jack Sparrow\n\nPrivacy: This starter keyboard does not send typed text to a server. বাংলা phonetic typing and automatic online updates are not included yet."
            textSize = 13f
            setTextColor(if (dark) Color.LTGRAY else Color.DKGRAY)
            gravity = Gravity.CENTER
        }
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun makeButton(label: String, color: Int, action: () -> Unit) =
        Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(color)
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun matchWrap(top: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = top }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "Telegram link খুলতে পারিনি।", Toast.LENGTH_SHORT).show() }
    }
}
