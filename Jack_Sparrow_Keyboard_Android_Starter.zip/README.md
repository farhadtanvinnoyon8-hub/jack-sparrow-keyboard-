# Jack Sparrow Keyboard — Android starter

Developer: Jack Sparrow

## Included
- Native Android Input Method Service (IME)
- English QWERTY starter layout
- Basic Bengali character layout (not phonetic/transliteration)
- Emoji panel
- Dark/Light app preference
- Telegram channel link and manual update announcement entry point
- No network permission and no typed-text collection

## Important limitations
- This is a starter implementation, not a tested/released APK.
- Bengali phonetic typing (`ami` -> `আমি`) is not included.
- Theme selection currently changes the app preference; reopen the keyboard to refresh.
- "Check for Updates" opens the configured Telegram channel. It does not silently update the APK or provide push notifications.
- The `?123` key is a placeholder and needs a proper numeric/symbol layout.
- Keyboard layout and behavior should be tested on real devices before release.

## Build APK
1. Open this folder in Android Studio (recent stable version).
2. Allow Gradle sync and install the required Android SDK (compile SDK 35).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on a test Android phone.
5. Open app > Enable Keyboard > select Jack Sparrow Keyboard.
6. Test in a text field, then review privacy and behavior before sharing publicly.

## Publish through Telegram
Upload the tested APK to your official Telegram channel. Include version, changelog, supported Android versions, SHA-256 checksum, and a clear privacy notice. Do not ask users to disable Android security protections.

## Configure the official channel
The starter uses `https://t.me/jacksparrow995` in `MainActivity.kt`. Replace it only if the official channel URL differs.
